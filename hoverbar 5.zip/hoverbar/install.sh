#!/usr/bin/env bash
# usage: ./install.sh [top|bottom] [--remove-panels]
set -e
EDGE=top; REMOVE=0
for a in "$@"; do
  case "$a" in
    top|bottom) EDGE="$a";;
    --remove-panels) REMOVE=1;;
    *) echo "usage: $0 [top|bottom] [--remove-panels]"; exit 1;;
  esac
done
cd "$(dirname "$0")"

# stop any old copy / old versions' leftovers
pkill -f hoverbar-session 2>/dev/null || true
pkill -x hoverbar 2>/dev/null || true
dbus-send --session --dest=org.kde.KWin --type=method_call /Scripting \
  org.kde.kwin.Scripting.unloadScript string:hoverbar-panelwatch >/dev/null 2>&1 || true

cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$HOME/.local"
cmake --build build -j"$(nproc)"
cmake --install build
install -Dm755 hoverbar-session "$HOME/.local/bin/hoverbar-session"

mkdir -p ~/.config/autostart
cat > ~/.config/autostart/hoverbar.desktop <<D
[Desktop Entry]
Type=Application
Name=HoverBar
Exec=$HOME/.local/bin/hoverbar-session --edge=$EDGE
X-KDE-autostart-phase=2
D

if [ "$REMOVE" = 1 ]; then
  B="$HOME/.config/hoverbar-backup"
  if [ ! -d "$B" ]; then
    mkdir -p "$B"
    cp ~/.config/plasma-org.kde.plasma.desktop-appletsrc ~/.config/plasmashellrc "$B"/ 2>/dev/null || true
    echo "Backed up current panels to $B"
  fi
  dbus-send --session --print-reply --dest=org.kde.plasmashell /PlasmaShell \
    org.kde.PlasmaShell.evaluateScript string:"var p=panels(); for (var i=p.length-1;i>=0;i--) p[i].remove(); 'removed '+p.length+' panel(s)'" || true
fi

setsid "$HOME/.local/bin/hoverbar-session" --edge="$EDGE" >/dev/null 2>&1 &
echo "HoverBar running on the $EDGE edge. Bind a shortcut to:  hoverbar --toggle-menu"
