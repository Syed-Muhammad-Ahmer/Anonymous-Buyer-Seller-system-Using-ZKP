#include <QCoreApplication>
#include <QGuiApplication>
#include <QQuickView>
#include <QQmlContext>
#include <QScreen>
#include <QDBusConnection>
#include <QDBusInterface>
#include <LayerShellQt/Shell>
#include <LayerShellQt/Window>
#include <cstdio>
#include "backend.h"

static constexpr int THIN = 26;          // collapsed bar height (also the reserved strip)
static constexpr int FULL = 58;          // expanded bar height == bar surface height

static void base(QQuickView &v) {
    v.setColor(Qt::transparent);
    v.setFlags(Qt::FramelessWindowHint);
    v.setResizeMode(QQuickView::SizeRootObjectToView);
}

int main(int argc, char **argv) {
    QString edge = "top";
    bool toggle = false, reset = false;
    for (int i = 1; i < argc; ++i) {
        QString a = argv[i];
        if (a.startsWith("--edge=")) edge = a.mid(7);
        else if (a == "--toggle-menu") toggle = true;
        else if (a == "--reset") reset = true;
    }
    if (edge != "top" && edge != "bottom") edge = "top";
    const bool bottom = edge == "bottom";

    // Remote-control mode: `hoverbar --toggle-menu` / `hoverbar --reset` talk to the running instance.
    if (toggle || reset) {
        QCoreApplication a(argc, argv);
        QDBusInterface i("org.hoverbar", "/Bar", "org.hoverbar.Bar", QDBusConnection::sessionBus());
        if (!i.isValid()) { std::fputs("hoverbar is not running\n", stderr); return 1; }
        i.call(toggle ? "toggleMenu" : "reset");
        return 0;
    }

    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    LayerShellQt::Shell::useLayerShell();
    QGuiApplication app(argc, argv);
    app.setApplicationName("hoverbar");
    app.setQuitOnLastWindowClosed(false);

    if (!QDBusConnection::sessionBus().registerService("org.hoverbar")) {
        std::fputs("hoverbar is already running\n", stderr);
        return 0;   // exit 0 so the session wrapper does not respawn a duplicate
    }

    QQuickView bar, menu;
    base(bar); base(menu);
    Backend be(&bar, &menu, bottom);
    QDBusConnection::sessionBus().registerObject("/Bar", &be, QDBusConnection::ExportAllSlots);

    for (QQuickView *v : {&bar, &menu}) {
        auto *c = v->rootContext();
        c->setContextProperty("sys", &be);
        c->setContextProperty("THIN", THIN);
        c->setContextProperty("FULL", FULL);
        c->setContextProperty("EDGE", edge);
    }
    menu.rootContext()->setContextProperty("apps", be.filter());
    bar.setSource(QUrl("qrc:/Main.qml"));
    menu.setSource(QUrl("qrc:/StartMenu.qml"));

    // ---- the bar: one strip at the chosen edge; only THIN px are reserved, expansion overlays windows ----
    auto side = bottom ? LayerShellQt::Window::AnchorBottom : LayerShellQt::Window::AnchorTop;
    auto *lw = LayerShellQt::Window::get(&bar);
    lw->setScope("hoverbar");
    lw->setLayer(LayerShellQt::Window::LayerTop);
    lw->setAnchors(LayerShellQt::Window::Anchors(side | LayerShellQt::Window::AnchorLeft | LayerShellQt::Window::AnchorRight));
    lw->setExclusiveZone(THIN);
    lw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    lw->setDesiredSize(QSize(0, FULL));
    bar.resize(1920, FULL);

    // ---- the start menu: a transparent full-screen overlay (click outside closes it) ----
    auto *mw = LayerShellQt::Window::get(&menu);
    mw->setScope("hoverbar-menu");
    mw->setLayer(LayerShellQt::Window::LayerOverlay);
    mw->setAnchors(LayerShellQt::Window::Anchors(LayerShellQt::Window::AnchorTop | LayerShellQt::Window::AnchorBottom |
        LayerShellQt::Window::AnchorLeft | LayerShellQt::Window::AnchorRight));
    mw->setExclusiveZone(-1);
    mw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityExclusive);
    mw->setDesiredSize(QSize(0, 0));
    menu.resize(1920, 1080);

    auto place = [&](QScreen *s) { if (s) { bar.setScreen(s); menu.setScreen(s); } };
    place(QGuiApplication::primaryScreen());
    QObject::connect(&app, &QGuiApplication::primaryScreenChanged, &app, place);

    bar.show();
    return app.exec();
}
