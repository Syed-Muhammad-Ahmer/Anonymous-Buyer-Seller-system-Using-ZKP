# HoverBar v4 – thin top/bottom bar → full custom taskbar + clickable start menu (Plasma 6, Wayland)

Idle: 26px mono bar (active window title, mini window icons, wifi, volume, battery, clock).
Hover: smooth expand into the full taskbar (pinned apps, open windows in stable order, show-desktop, tray).
Click the KDE logo (thin or full bar): full start menu – search, categories, pinned, recent, all apps, power.

## Install
    ./install.sh top                  # or: ./install.sh bottom
    ./install.sh top --remove-panels  # also removes the stock KDE panel(s) (backed up first)
Deps: cmake, Qt6 declarative+dbus, layer-shell-qt, plasma-workspace (libtaskmanager), kirigami, kde-cli-tools,
pactl, qdbus6. Arch: sudo pacman -S cmake qt6-declarative layer-shell-qt plasma-workspace kirigami kde-cli-tools
Undo: ./uninstall.sh (restores the original panel if you used --remove-panels).

## Start menu
- Click the logo to toggle. Click anywhere outside, or press Esc, to close.
- Type to search · ↑/↓ to move · Enter to launch · right-click an app to pin/unpin it to the taskbar.
- Bind a global shortcut (System Settings > Shortcuts > Add Command) to `hoverbar --toggle-menu`
  (e.g. Meta key; disable KDE's own Meta shortcut first).

## Taskbar
Left click = focus / launch · middle = new instance · right = close window ·
scroll on volume icon = volume, click = mute.

## What keeps it from getting stuck
- The input region only shrinks after the collapse animation; hover enter/leave can't desync it.
- A 1.5 s watchdog repairs any missed hover event; the active title/clock are polled, never stale.
- Start menu is a full-screen overlay (click-outside + Esc + timeout fallback) – can't stay open.
- `hoverbar-session` auto-restarts the bar if it ever crashes.
- Emergency reset without restarting anything: `hoverbar --reset`.
