#!/usr/bin/env bash
pkill -f hoverbar-session; pkill -x hoverbar
rm -f ~/.local/bin/hoverbar ~/.local/bin/hoverbar-session ~/.config/autostart/hoverbar.desktop
B="$HOME/.config/hoverbar-backup"
if [ -d "$B" ]; then
  cp "$B"/plasma-org.kde.plasma.desktop-appletsrc "$B"/plasmashellrc ~/.config/ 2>/dev/null
  systemctl --user restart plasma-plasmashell.service 2>/dev/null || { kquitapp6 plasmashell; sleep 1; setsid plasmashell >/dev/null 2>&1 & }
  echo "Original KDE panel restored."
fi
