import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager

Item {
    id: root
    readonly property bool atBottom: EDGE === "bottom"
    property bool expanded: false
    property real barH: expanded ? FULL : THIN
    Behavior on barH { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }
    readonly property real p: Math.max(0, Math.min(1, (barH - THIN) / (FULL - THIN)))
    property date now: new Date()
    property int batt: sys.battery()
    property string activeTitle: "Desktop"
    readonly property var launchers: {
        var o = []; var l = sys.pinned
        for (var i = 0; i < l.length; i++) o.push("applications:" + l[i])
        return o
    }

    // ---------- hover state machine (self-healing) ----------
    function wake()  { leaveT.stop(); maskT.stop(); if (!expanded) { sys.setBarHeight(FULL); expanded = true } }
    function sleep() { if (expanded) { expanded = false; maskT.restart() } }
    HoverHandler {
        id: hover
        onHoveredChanged: { if (hovered) root.wake(); else leaveT.restart() }
    }
    Timer { id: leaveT; interval: 420; onTriggered: if (!hover.hovered && !sys.menuOpen) root.sleep() }
    // shrink the input region only AFTER the collapse animation, never while the pointer may be inside
    Timer { id: maskT; interval: 340; onTriggered: if (!root.expanded) sys.setBarHeight(THIN) }
    // watchdog: repairs any missed enter/leave event so nothing can stay stuck
    Timer {
        interval: 1500; running: true; repeat: true
        onTriggered: {
            if (root.expanded && !hover.hovered && !sys.menuOpen && !leaveT.running) root.sleep()
            else if (!root.expanded && hover.hovered) root.wake()
            else if (!root.expanded && !maskT.running) sys.setBarHeight(THIN)
        }
    }
    Connections {
        target: sys
        function onMenuOpenChanged() { if (sys.menuOpen) root.wake(); else leaveT.restart() }
        function onResetRequested() { root.sleep() }
    }
    Component.onCompleted: sys.setBarHeight(THIN)

    // ---------- clock / battery / active window title (polled: can never go stale) ----------
    Timer {
        interval: 500; running: true; repeat: true; triggeredOnStart: true
        onTriggered: {
            root.now = new Date(); root.batt = sys.battery()
            var t = "Desktop"
            for (var i = 0; i < winTasks.count; i++) {
                var ix = winTasks.index(i, 0)
                if (winTasks.data(ix, TaskManager.AbstractTasksModel.IsActive)) { t = winTasks.data(ix, Qt.DisplayRole); break }
            }
            root.activeTitle = t
        }
    }

    TaskManager.VirtualDesktopInfo { id: vdi }
    TaskManager.ActivityInfo { id: ai }
    // plain list of windows (thin bar)
    TaskManager.TasksModel {
        id: winTasks
        virtualDesktop: vdi.currentDesktop; activity: ai.currentActivity
        filterByVirtualDesktop: false; filterByScreen: false
        groupMode: TaskManager.TasksModel.GroupDisable
        sortMode: TaskManager.TasksModel.SortManual
    }
    // pinned apps first, then windows in the order they were opened (expanded bar)
    TaskManager.TasksModel {
        id: tasks
        virtualDesktop: vdi.currentDesktop; activity: ai.currentActivity
        filterByVirtualDesktop: false; filterByScreen: false
        groupMode: TaskManager.TasksModel.GroupDisable
        sortMode: TaskManager.TasksModel.SortManual
        separateLaunchers: false
        launcherList: root.launchers
    }

    component StatusArea: RowLayout {
        property int iconSize: 14
        property int fontSize: 11
        spacing: 10
        Kirigami.Icon { source: "network-wireless-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("systemsettings kcm_networkmanagement") } }
        Kirigami.Icon { source: "audio-volume-high-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("pactl set-sink-mute @DEFAULT_SINK@ toggle") }
            WheelHandler { onWheel: function (e) {
                sys.run("pactl set-sink-volume @DEFAULT_SINK@ " + (e.angleDelta.y > 0 ? "+5%" : "-5%")) } } }
        RowLayout { visible: root.batt >= 0; spacing: 3
            Kirigami.Icon { source: "battery-symbolic"; isMask: true; color: "white"
                implicitWidth: iconSize; implicitHeight: iconSize }
            Text { text: root.batt + "%"; color: "white"; font.pixelSize: fontSize } }
        Text { text: Qt.formatDateTime(root.now, "ddd d MMM  hh:mm"); color: "white"
            font.pixelSize: fontSize + 1; font.weight: Font.Medium }
    }

    // background: rounded rect that overshoots the screen edge so only the inner corners show
    Rectangle {
        id: bg
        width: parent.width
        height: root.barH + 16
        y: root.atBottom ? root.height - root.barH : -16
        radius: 16 * root.p
        color: Qt.rgba(0.08, 0.08, 0.09, 0.82 + 0.10 * root.p)
    }

    Item {
        id: content
        width: parent.width
        height: root.barH
        y: root.atBottom ? root.height - root.barH : 0

        // ---------- collapsed: thin mono bar ----------
        Item {
            anchors.fill: parent
            opacity: 1 - root.p
            visible: opacity > 0.01
            RowLayout {
                anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                spacing: 10
                Kirigami.Icon { source: "start-here-kde-symbolic"; isMask: true; color: "white"
                    implicitWidth: 13; implicitHeight: 13
                    TapHandler { onTapped: sys.toggleMenu() } }
                Text { text: root.activeTitle; color: "white"; font.pixelSize: 12; font.weight: Font.DemiBold
                    elide: Text.ElideRight; Layout.maximumWidth: 280 }
                ListView {
                    model: winTasks
                    orientation: ListView.Horizontal; interactive: false; clip: true; spacing: 8
                    Layout.preferredWidth: Math.min(contentWidth, 520)
                    Layout.preferredHeight: 14
                    delegate: Kirigami.Icon {
                        required property var model
                        width: 12; height: 12
                        source: model.decoration
                        isMask: true; color: "white"; opacity: model.IsActive ? 1.0 : 0.4
                    }
                }
            }
            StatusArea { anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } }
        }

        // ---------- expanded: full taskbar ----------
        Item {
            anchors.fill: parent
            opacity: root.p
            visible: opacity > 0.01
            transform: Translate { y: (1 - root.p) * (root.atBottom ? 8 : -8) }

            Kirigami.Icon {   // start button: click toggles the start menu
                anchors { left: parent.left; leftMargin: 18; verticalCenter: parent.verticalCenter }
                source: "start-here-kde"; implicitWidth: 34; implicitHeight: 34
                scale: sh.hovered || sys.menuOpen ? 1.15 : 1.0
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                HoverHandler { id: sh }
                TapHandler { onTapped: sys.toggleMenu() }
            }

            ListView {
                id: dock
                anchors.centerIn: parent
                width: Math.min(contentWidth, Math.max(0, parent.width - 560)); height: 50
                model: tasks
                orientation: ListView.Horizontal; interactive: false; clip: true; spacing: 8
                delegate: Item {
                    id: cell
                    required property int index
                    required property var model
                    width: 44; height: 50
                    Kirigami.Icon {
                        anchors { centerIn: parent; verticalCenterOffset: -3 }
                        source: cell.model.decoration
                        width: 34; height: 34
                        opacity: cell.model.IsWindow ? 1.0 : 0.75
                        scale: th.hovered ? 1.25 : 1.0
                        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                    }
                    Rectangle {
                        visible: cell.model.IsWindow
                        width: cell.model.IsActive ? 14 : 5; height: 4; radius: 2; color: "white"
                        Behavior on width { NumberAnimation { duration: 150 } }
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 2 }
                    }
                    HoverHandler { id: th }
                    TapHandler { onTapped: {
                        var ix = tasks.makeModelIndex(cell.index)
                        if (cell.model.IsWindow) tasks.requestActivate(ix); else tasks.requestNewInstance(ix) } }
                    TapHandler { acceptedButtons: Qt.MiddleButton
                        onTapped: tasks.requestNewInstance(tasks.makeModelIndex(cell.index)) }
                    TapHandler { acceptedButtons: Qt.RightButton
                        onTapped: if (cell.model.IsWindow) tasks.requestClose(tasks.makeModelIndex(cell.index)) }
                }
            }

            RowLayout {
                anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                spacing: 16
                Kirigami.Icon { source: "user-desktop-symbolic"; isMask: true; color: "white"
                    implicitWidth: 20; implicitHeight: 20
                    TapHandler { onTapped: sys.run("qdbus6 org.kde.kglobalaccel /component/kwin org.kde.kglobalaccel.Component.invokeShortcut \"Show Desktop\"") } }
                StatusArea { iconSize: 20; fontSize: 13 }
            }
        }
    }
}
