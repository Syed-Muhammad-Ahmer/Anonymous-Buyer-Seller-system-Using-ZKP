#pragma once
#include <QObject>
#include <QAbstractListModel>
#include <QSortFilterProxyModel>
#include <QDirIterator>
#include <QStandardPaths>
#include <QSettings>
#include <QProcess>
#include <QTimer>
#include <QFile>
#include <QLocale>
#include <QQuickView>
#include <QRegion>
#include <QVariantList>
#include <QVariantMap>
#include <algorithm>

struct AppEntry { QString id, name, icon, comment, generic, path; QStringList cats; };

// ---------- installed applications (parsed from .desktop files) ----------
class AppModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum Roles { NameRole = Qt::UserRole + 1, IconRole, CommentRole, IdRole, CatsRole, GenericRole };
    explicit AppModel(QObject *p = nullptr) : QAbstractListModel(p) { load(); }
    int rowCount(const QModelIndex &i = {}) const override { return i.isValid() ? 0 : m_apps.size(); }
    QVariant data(const QModelIndex &i, int r) const override {
        if (!i.isValid() || i.row() >= m_apps.size()) return {};
        const AppEntry &a = m_apps[i.row()];
        switch (r) {
        case NameRole: return a.name;   case IconRole: return a.icon;
        case CommentRole: return a.comment; case IdRole: return a.id;
        case CatsRole: return a.cats;   case GenericRole: return a.generic;
        }
        return {};
    }
    QHash<int, QByteArray> roleNames() const override {
        return {{NameRole, "name"}, {IconRole, "icon"}, {CommentRole, "comment"},
                {IdRole, "appId"}, {CatsRole, "cats"}, {GenericRole, "generic"}};
    }
    const AppEntry *find(const QString &id) const {
        for (const auto &a : m_apps) if (a.id == id) return &a;
        return nullptr;
    }
private:
    void load() {
        QSet<QString> seen;
        const QString lang = QLocale::system().name();
        for (const QString &dir : QStandardPaths::standardLocations(QStandardPaths::ApplicationsLocation)) {
            QDirIterator it(dir, {"*.desktop"}, QDir::Files, QDirIterator::Subdirectories);
            while (it.hasNext()) {
                QString path = it.next();
                QString id = QDir(dir).relativeFilePath(path).replace('/', '-');
                if (seen.contains(id)) continue;
                seen.insert(id);
                QFile f(path);
                if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) continue;
                AppEntry a; a.id = id; a.path = path;
                bool in = false, hide = false, isApp = false;
                QString localName;
                while (!f.atEnd()) {
                    QString l = QString::fromUtf8(f.readLine()).trimmed();
                    if (l.startsWith('[')) { if (in) break; in = (l == "[Desktop Entry]"); continue; }
                    if (!in) continue;
                    int eq = l.indexOf('=');
                    if (eq < 0) continue;
                    QString k = l.left(eq), v = l.mid(eq + 1);
                    if (k == "Type") isApp = (v == "Application");
                    else if (k == "Name") a.name = v;
                    else if (k == "Name[" + lang + "]" || k == "Name[" + lang.section('_', 0, 0) + "]") localName = v;
                    else if (k == "Comment") a.comment = v;
                    else if (k == "GenericName") a.generic = v;
                    else if (k == "Icon") a.icon = v;
                    else if (k == "NoDisplay" || k == "Hidden") { if (v == "true") hide = true; }
                    else if (k == "Categories") a.cats = v.split(';', Qt::SkipEmptyParts);
                }
                if (!localName.isEmpty()) a.name = localName;
                if (isApp && !hide && !a.name.isEmpty()) m_apps.push_back(a);
            }
        }
        std::sort(m_apps.begin(), m_apps.end(), [](const AppEntry &x, const AppEntry &y) {
            return x.name.compare(y.name, Qt::CaseInsensitive) < 0; });
    }
    QList<AppEntry> m_apps;
};

// ---------- search + category filter ----------
class AppFilter : public QSortFilterProxyModel {
    Q_OBJECT
    Q_PROPERTY(QString query MEMBER m_q NOTIFY changed)
    Q_PROPERTY(QString category MEMBER m_c NOTIFY changed)
public:
    AppFilter(QAbstractItemModel *src, QObject *p) : QSortFilterProxyModel(p) {
        setSourceModel(src);
        connect(this, &AppFilter::changed, this, [this] { invalidateFilter(); });
    }
    Q_INVOKABLE QString firstId() const {
        return rowCount() ? data(index(0, 0), AppModel::IdRole).toString() : QString();
    }
signals:
    void changed();
protected:
    bool filterAcceptsRow(int r, const QModelIndex &) const override {
        auto i = sourceModel()->index(r, 0);
        if (!m_c.isEmpty() && !sourceModel()->data(i, AppModel::CatsRole).toStringList().contains(m_c)) return false;
        if (m_q.isEmpty()) return true;
        for (int role : {int(AppModel::NameRole), int(AppModel::CommentRole), int(AppModel::GenericRole)})
            if (sourceModel()->data(i, role).toString().contains(m_q, Qt::CaseInsensitive)) return true;
        return false;
    }
private:
    QString m_q, m_c;
};

// ---------- shared backend (bar + start menu) ----------
class Backend : public QObject {
    Q_OBJECT
    Q_PROPERTY(QStringList pinned READ pinned NOTIFY pinnedChanged)
    Q_PROPERTY(QVariantList pinnedApps READ pinnedApps NOTIFY pinnedChanged)
    Q_PROPERTY(QVariantList recentApps READ recentApps NOTIFY recentChanged)
    Q_PROPERTY(bool menuOpen READ menuOpen NOTIFY menuOpenChanged)
    Q_PROPERTY(QString userName READ userName CONSTANT)
public:
    Backend(QQuickView *bar, QQuickView *menu) : QObject(bar), m_bar(bar), m_menu(menu), m_s("hoverbar", "hoverbar") {
        m_filter = new AppFilter(&m_model, this);
        m_pinned = m_s.value("pinned").toStringList();
        if (!m_s.contains("pinned")) {
            for (const char *c : {"org.kde.dolphin.desktop", "org.kde.konsole.desktop", "firefox.desktop",
                                  "org.mozilla.firefox.desktop", "systemsettings.desktop", "org.kde.kate.desktop"})
                if (m_model.find(c)) m_pinned << c;
            m_s.setValue("pinned", m_pinned);
        }
        m_recent = m_s.value("recent").toStringList();
        m_openT.setSingleShot(true);  m_openT.setInterval(160);
        m_closeT.setSingleShot(true); m_closeT.setInterval(700);
        connect(&m_openT, &QTimer::timeout, this, [this] { if (m_lh) showMenu(true); });
        connect(&m_closeT, &QTimer::timeout, this, [this] { if (!m_lh && !m_mh) showMenu(false); });
    }
    QObject *filter() { return m_filter; }
    QStringList pinned() const { return m_pinned; }
    bool menuOpen() const { return m_open; }
    QString userName() const { return qEnvironmentVariable("USER"); }
    QVariantList pinnedApps() const { return toList(m_pinned); }
    QVariantList recentApps() const { return toList(m_recent); }

    Q_INVOKABLE void setInputHeight(int h) { m_bar->setMask(QRegion(0, 0, m_bar->width(), h)); }
    Q_INVOKABLE void run(const QString &cmd) {
        QStringList a = QProcess::splitCommand(cmd);
        if (a.isEmpty()) return;
        QString p = a.takeFirst();
        QProcess::startDetached(p, a);
    }
    Q_INVOKABLE int battery() {
        QFile f("/sys/class/power_supply/BAT0/capacity");
        return f.open(QIODevice::ReadOnly) ? f.readAll().trimmed().toInt() : -1;
    }
    Q_INVOKABLE void showMenu(bool v) {
        if (v == m_open) return;
        m_open = v;
        if (v) { m_menu->show(); m_menu->requestActivate(); } else m_menu->hide();
        emit menuOpenChanged();
    }
    Q_INVOKABLE void toggleMenu() { showMenu(!m_open); }
    Q_INVOKABLE void setLauncherHovered(bool h) {
        m_lh = h;
        if (h) { m_closeT.stop(); m_openT.start(); } else { m_openT.stop(); m_closeT.start(); }
    }
    Q_INVOKABLE void setMenuHovered(bool h) { m_mh = h; if (h) m_closeT.stop(); else m_closeT.start(); }
    Q_INVOKABLE void togglePin(const QString &id) {
        if (!m_pinned.removeOne(id)) m_pinned << id;
        m_s.setValue("pinned", m_pinned);
        emit pinnedChanged();
    }
    Q_INVOKABLE void launchApp(const QString &id) {
        const AppEntry *a = m_model.find(id);
        if (!a) return;
        if (!QProcess::startDetached("kioclient6", {"exec", a->path}))
            if (!QProcess::startDetached("kioclient", {"exec", a->path}))
                QProcess::startDetached("gtk-launch", {id});
        m_recent.removeAll(id); m_recent.prepend(id);
        while (m_recent.size() > 8) m_recent.removeLast();
        m_s.setValue("recent", m_recent);
        emit recentChanged();
        showMenu(false);
    }
signals:
    void pinnedChanged();
    void recentChanged();
    void menuOpenChanged();
private:
    QVariantList toList(const QStringList &ids) const {
        QVariantList out;
        for (const QString &id : ids)
            if (const AppEntry *a = m_model.find(id))
                out << QVariantMap{{"appId", a->id}, {"name", a->name}, {"icon", a->icon}};
        return out;
    }
    QQuickView *m_bar, *m_menu;
    QSettings m_s;
    AppModel m_model;
    AppFilter *m_filter;
    QStringList m_pinned, m_recent;
    QTimer m_openT, m_closeT;
    bool m_open = false, m_lh = false, m_mh = false;
};
