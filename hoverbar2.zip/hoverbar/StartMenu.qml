import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

Rectangle {
    id: win
    color: Qt.rgba(0.09, 0.09, 0.10, 0.95)
    radius: 18
    border.color: Qt.rgba(1, 1, 1, 0.08)
    property string cat: ""
    readonly property var cats: [
        {l: "All apps", k: ""}, {l: "Multimedia", k: "AudioVideo"}, {l: "Development", k: "Development"},
        {l: "Games", k: "Game"}, {l: "Graphics", k: "Graphics"}, {l: "Internet", k: "Network"},
        {l: "Office", k: "Office"}, {l: "Settings", k: "Settings"}, {l: "System", k: "System"},
        {l: "Utilities", k: "Utility"}]

    transform: Translate { y: (1 - win.opacity) * -16 }
    NumberAnimation { id: appear; target: win; property: "opacity"; from: 0; to: 1; duration: 220; easing.type: Easing.OutCubic }
    Connections {
        target: sys
        function onMenuOpenChanged() {
            if (sys.menuOpen) { search.text = ""; win.cat = ""; apps.category = ""; appear.restart(); search.forceActiveFocus() }
        }
    }
    HoverHandler { onHoveredChanged: sys.setMenuHovered(hovered) }

    component PowerBtn: Rectangle {
        property string ico; property string cmd; property string tip
        implicitWidth: 34; implicitHeight: 34; radius: 10
        color: ph.hovered ? Qt.rgba(1, 1, 1, 0.14) : "transparent"
        Kirigami.Icon { anchors.centerIn: parent; source: parent.ico; isMask: true; color: "white"; width: 18; height: 18 }
        HoverHandler { id: ph }
        TapHandler { onTapped: { sys.showMenu(false); sys.run(parent.cmd) } }
    }

    ColumnLayout {
        anchors { fill: parent; margins: 16 }
        spacing: 12

        Rectangle {   // search
            Layout.fillWidth: true; implicitHeight: 42; radius: 12; color: Qt.rgba(1, 1, 1, 0.08)
            RowLayout { anchors { fill: parent; leftMargin: 12; rightMargin: 12 } spacing: 10
                Kirigami.Icon { source: "search-symbolic"; isMask: true; color: "white"; implicitWidth: 18; implicitHeight: 18; opacity: 0.7 }
                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: "white"; font.pixelSize: 15; clip: true
                    selectionColor: "#3daee9"
                    onTextChanged: apps.query = text
                    Keys.onEscapePressed: sys.showMenu(false)
                    Keys.onReturnPressed: { var id = apps.firstId(); if (id) sys.launchApp(id) }
                    Text { visible: !search.text; text: "Search apps…"; color: "white"; opacity: 0.45; font.pixelSize: 15 }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true; Layout.fillHeight: true; spacing: 14

            ColumnLayout {   // categories
                Layout.preferredWidth: 140; Layout.fillHeight: true; spacing: 2
                Repeater {
                    model: win.cats
                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true; implicitHeight: 32; radius: 8
                        color: win.cat === modelData.k ? Qt.rgba(1, 1, 1, 0.16) : (ch.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent")
                        Text { anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                            text: modelData.l; color: "white"; font.pixelSize: 13 }
                        HoverHandler { id: ch }
                        TapHandler { onTapped: { win.cat = modelData.k; apps.category = modelData.k } }
                    }
                }
                Item { Layout.fillHeight: true }
            }

            ListView {
                id: list
                Layout.fillWidth: true; Layout.fillHeight: true
                clip: true; model: apps; spacing: 2
                boundsBehavior: Flickable.StopAtBounds
                header: Column {
                    width: list.width
                    visible: search.text === "" && win.cat === ""
                    height: visible ? implicitHeight : 0
                    spacing: 6
                    Text { text: "Pinned"; color: "white"; opacity: 0.6; font.pixelSize: 12; font.weight: Font.DemiBold; visible: sys.pinnedApps.length > 0 }
                    Flow {
                        width: parent.width; spacing: 4
                        Repeater {
                            model: sys.pinnedApps
                            delegate: Rectangle {
                                required property var modelData
                                width: 92; height: 82; radius: 10
                                color: pt.hovered ? Qt.rgba(1, 1, 1, 0.10) : "transparent"
                                Column { anchors.centerIn: parent; spacing: 6
                                    Kirigami.Icon { source: modelData.icon; width: 40; height: 40; anchors.horizontalCenter: parent.horizontalCenter }
                                    Text { text: modelData.name; color: "white"; font.pixelSize: 11; width: 84
                                        horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight } }
                                HoverHandler { id: pt }
                                TapHandler { onTapped: sys.launchApp(modelData.appId) }
                                TapHandler { acceptedButtons: Qt.RightButton; onTapped: sys.togglePin(modelData.appId) }
                            }
                        }
                    }
                    Text { text: "Recent"; color: "white"; opacity: 0.6; font.pixelSize: 12; font.weight: Font.DemiBold; visible: sys.recentApps.length > 0 }
                    Flow {
                        width: parent.width; spacing: 4
                        Repeater {
                            model: sys.recentApps
                            delegate: Rectangle {
                                required property var modelData
                                width: 92; height: 82; radius: 10
                                color: rt.hovered ? Qt.rgba(1, 1, 1, 0.10) : "transparent"
                                Column { anchors.centerIn: parent; spacing: 6
                                    Kirigami.Icon { source: modelData.icon; width: 40; height: 40; anchors.horizontalCenter: parent.horizontalCenter }
                                    Text { text: modelData.name; color: "white"; font.pixelSize: 11; width: 84
                                        horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight } }
                                HoverHandler { id: rt }
                                TapHandler { onTapped: sys.launchApp(modelData.appId) }
                            }
                        }
                    }
                    Text { text: "All apps"; color: "white"; opacity: 0.6; font.pixelSize: 12; font.weight: Font.DemiBold }
                }
                delegate: Rectangle {
                    id: row
                    required property var model
                    width: list.width; height: 44; radius: 10
                    color: rh.hovered ? Qt.rgba(1, 1, 1, 0.10) : "transparent"
                    RowLayout { anchors { fill: parent; leftMargin: 10; rightMargin: 10 } spacing: 12
                        Kirigami.Icon { source: row.model.icon; implicitWidth: 28; implicitHeight: 28 }
                        ColumnLayout { Layout.fillWidth: true; spacing: 0
                            Text { text: row.model.name; color: "white"; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true }
                            Text { text: row.model.comment; color: "white"; opacity: 0.5; font.pixelSize: 10; elide: Text.ElideRight
                                Layout.fillWidth: true; visible: text !== "" } }
                        Kirigami.Icon { source: "bookmark-new-symbolic"; isMask: true; color: "white"; implicitWidth: 14; implicitHeight: 14
                            opacity: sys.pinned.indexOf(row.model.appId) >= 0 ? 0.9 : 0.0 }
                    }
                    HoverHandler { id: rh }
                    TapHandler { onTapped: sys.launchApp(row.model.appId) }
                    TapHandler { acceptedButtons: Qt.RightButton; onTapped: sys.togglePin(row.model.appId) }
                }
            }
        }

        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Qt.rgba(1, 1, 1, 0.08) }
        RowLayout {
            Layout.fillWidth: true; spacing: 6
            Kirigami.Icon { source: "user-identity"; implicitWidth: 28; implicitHeight: 28 }
            Text { text: sys.userName; color: "white"; font.pixelSize: 13; font.weight: Font.Medium }
            Item { Layout.fillWidth: true }
            Text { text: "Right-click an app to pin / unpin"; color: "white"; opacity: 0.35; font.pixelSize: 10 }
            PowerBtn { ico: "system-lock-screen"; cmd: "loginctl lock-session" }
            PowerBtn { ico: "system-suspend"; cmd: "systemctl suspend" }
            PowerBtn { ico: "system-log-out"; cmd: "qdbus6 org.kde.Shutdown /Shutdown logout" }
            PowerBtn { ico: "system-reboot"; cmd: "systemctl reboot" }
            PowerBtn { ico: "system-shutdown"; cmd: "systemctl poweroff" }
        }
    }
}
