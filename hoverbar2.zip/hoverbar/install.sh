#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$HOME/.local"
cmake --build build -j"$(nproc)"
cmake --install build
mkdir -p ~/.config/autostart
cat > ~/.config/autostart/hoverbar.desktop <<D
[Desktop Entry]
Type=Application
Name=HoverBar
Exec=$HOME/.local/bin/hoverbar
X-KDE-autostart-phase=2
D
echo "Installed. Remove the default panel (right-click panel > Edit Mode > Delete Panel), then run: hoverbar"
