#include <QGuiApplication>
#include <QQuickView>
#include <QQmlContext>
#include <LayerShellQt/Shell>
#include <LayerShellQt/Window>
#include "backend.h"

static constexpr int THIN = 26;          // reserved strip at the very top of the screen
static constexpr int FULL_BAR = 58;      // expanded bar height
static constexpr int FULL_SURFACE = 80;  // bar surface height (>= FULL_BAR)
static constexpr int MENU_W = 720, MENU_H = 560;

static void base(QQuickView &v) {
    v.setColor(Qt::transparent);
    v.setFlags(Qt::FramelessWindowHint);
    v.setResizeMode(QQuickView::SizeRootObjectToView);
}

int main(int argc, char **argv) {
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    LayerShellQt::Shell::useLayerShell();
    QGuiApplication app(argc, argv);
    app.setQuitOnLastWindowClosed(false);

    QQuickView bar, menu;
    base(bar); base(menu);
    Backend be(&bar, &menu);

    for (QQuickView *v : {&bar, &menu}) v->rootContext()->setContextProperty("sys", &be);
    bar.rootContext()->setContextProperty("THIN", THIN);
    bar.rootContext()->setContextProperty("FULL", FULL_BAR);
    menu.rootContext()->setContextProperty("apps", be.filter());
    bar.setSource(QUrl("qrc:/Main.qml"));
    menu.setSource(QUrl("qrc:/StartMenu.qml"));

    // Top-of-screen bar: pinned to the top edge, spanning the full width, above windows.
    auto *lw = LayerShellQt::Window::get(&bar);
    lw->setScope("hoverbar");
    lw->setLayer(LayerShellQt::Window::LayerTop);
    lw->setAnchors(LayerShellQt::Window::Anchors(LayerShellQt::Window::AnchorTop |
        LayerShellQt::Window::AnchorLeft | LayerShellQt::Window::AnchorRight));
    lw->setExclusiveZone(THIN);
    lw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    lw->setDesiredSize(QSize(0, FULL_SURFACE));
    bar.resize(1920, FULL_SURFACE);

    // Start menu: drops down from the top-left, directly under the expanded bar.
    auto *mw = LayerShellQt::Window::get(&menu);
    mw->setScope("hoverbar-menu");
    mw->setLayer(LayerShellQt::Window::LayerTop);
    mw->setAnchors(LayerShellQt::Window::Anchors(LayerShellQt::Window::AnchorTop | LayerShellQt::Window::AnchorLeft));
    mw->setMargins(QMargins(10, FULL_BAR + 2, 0, 0));
    mw->setExclusiveZone(-1);
    mw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityOnDemand);
    mw->setDesiredSize(QSize(MENU_W, MENU_H));
    menu.resize(MENU_W, MENU_H);

    bar.show();
    return app.exec();
}
