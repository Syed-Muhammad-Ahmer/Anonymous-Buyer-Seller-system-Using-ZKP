import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager

Item {
    id: root
    readonly property bool expanded: hover.hovered || holdTimer.running || sys.menuOpen
    readonly property real p: Math.max(0, Math.min(1, (bar.height - THIN) / (FULL - THIN)))
    property date now: new Date()
    property int batt: sys.battery()
    property string activeTitle: "Desktop"
    readonly property var launchers: {
        var o = []; var l = sys.pinned
        for (var i = 0; i < l.length; i++) o.push("applications:" + l[i])
        return o
    }

    HoverHandler { id: hover; onHoveredChanged: if (!hovered) holdTimer.restart() }
    Timer { id: holdTimer; interval: 450 }
    Timer { interval: 1000; running: true; repeat: true
        onTriggered: { root.now = new Date(); root.batt = sys.battery() } }
    Connections { target: sys; function onMenuOpenChanged() { if (!sys.menuOpen) holdTimer.restart() } }

    TaskManager.VirtualDesktopInfo { id: vdi }
    TaskManager.ActivityInfo { id: ai }
    TaskManager.TasksModel {
        id: tasks
        virtualDesktop: vdi.currentDesktop
        activity: ai.currentActivity
        filterByVirtualDesktop: false
        filterByScreen: false
        groupMode: TaskManager.TasksModel.GroupDisable
        sortMode: TaskManager.TasksModel.SortManual   // stable order: pinned first, then windows as opened
        separateLaunchers: false
        launcherList: root.launchers
    }

    component StatusArea: RowLayout {
        property int iconSize: 14
        property int fontSize: 11
        spacing: 10
        Kirigami.Icon { source: "network-wireless-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("systemsettings kcm_networkmanagement") } }
        Kirigami.Icon { source: "audio-volume-high-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("pactl set-sink-mute @DEFAULT_SINK@ toggle") }
            WheelHandler { onWheel: function (e) {
                sys.run("pactl set-sink-volume @DEFAULT_SINK@ " + (e.angleDelta.y > 0 ? "+5%" : "-5%")) } } }
        RowLayout { visible: root.batt >= 0; spacing: 3
            Kirigami.Icon { source: "battery-symbolic"; isMask: true; color: "white"
                implicitWidth: iconSize; implicitHeight: iconSize }
            Text { text: root.batt + "%"; color: "white"; font.pixelSize: fontSize } }
        Text { text: Qt.formatDateTime(root.now, "ddd d MMM  hh:mm"); color: "white"
            font.pixelSize: fontSize + 1; font.weight: Font.Medium }
    }

    Rectangle {
        id: bar
        width: parent.width
        height: root.expanded ? FULL : THIN
        color: Qt.rgba(0.08, 0.08, 0.09, 0.80 + 0.12 * root.p)
        bottomLeftRadius: 16 * root.p
        bottomRightRadius: 16 * root.p
        Behavior on height { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }
        onHeightChanged: sys.setInputHeight(Math.ceil(height))

        // ---------- collapsed: thin mono bar ----------
        Item {
            anchors.fill: parent
            opacity: 1 - root.p
            visible: opacity > 0.01
            RowLayout {
                anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                spacing: 10
                Kirigami.Icon { source: "start-here-kde-symbolic"; isMask: true; color: "white"
                    implicitWidth: 13; implicitHeight: 13 }
                Text { text: root.activeTitle; color: "white"; font.pixelSize: 12; font.weight: Font.DemiBold
                    elide: Text.ElideRight; Layout.maximumWidth: 280 }
                Repeater {
                    model: tasks
                    delegate: Kirigami.Icon {
                        id: mini
                        required property var model
                        readonly property bool act: model.IsActive
                        readonly property string t: model.display
                        onActChanged: if (act) root.activeTitle = t
                        onTChanged: if (act) root.activeTitle = t
                        Component.onCompleted: if (act) root.activeTitle = t
                        source: model.decoration; implicitWidth: 12; implicitHeight: 12
                        isMask: true; color: "white"; opacity: act ? 1.0 : 0.4
                    }
                }
            }
            StatusArea { anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } }
        }

        // ---------- expanded: full taskbar ----------
        Item {
            anchors.fill: parent
            opacity: root.p
            visible: opacity > 0.01
            transform: Translate { y: (1 - root.p) * -8 }

            Kirigami.Icon {   // start button: hover opens the start menu, click toggles it
                id: startBtn
                anchors { left: parent.left; leftMargin: 18; verticalCenter: parent.verticalCenter }
                source: "start-here-kde"; implicitWidth: 34; implicitHeight: 34
                scale: sh.hovered || sys.menuOpen ? 1.15 : 1.0
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                HoverHandler { id: sh; onHoveredChanged: sys.setLauncherHovered(hovered) }
                TapHandler { onTapped: sys.toggleMenu() }
            }

            RowLayout {
                anchors.centerIn: parent
                spacing: 10
                Repeater {
                    model: tasks
                    delegate: Item {
                        id: cell
                        required property int index
                        required property var model
                        implicitWidth: 44; implicitHeight: 44
                        Kirigami.Icon {
                            anchors.centerIn: parent
                            source: cell.model.decoration
                            width: 34; height: 34
                            opacity: cell.model.IsWindow ? 1.0 : 0.75
                            scale: th.hovered ? 1.28 : 1.0
                            Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                        }
                        Rectangle {
                            width: cell.model.IsActive ? 14 : 5; height: 5; radius: 3; color: "white"
                            Behavior on width { NumberAnimation { duration: 150 } }
                            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: -3 }
                            visible: cell.model.IsWindow
                        }
                        HoverHandler { id: th }
                        TapHandler { onTapped: {
                            var ix = tasks.makeModelIndex(cell.index)
                            if (cell.model.IsWindow) tasks.requestActivate(ix); else tasks.requestNewInstance(ix) } }
                        TapHandler { acceptedButtons: Qt.MiddleButton
                            onTapped: tasks.requestNewInstance(tasks.makeModelIndex(cell.index)) }
                        TapHandler { acceptedButtons: Qt.RightButton
                            onTapped: if (cell.model.IsWindow) tasks.requestClose(tasks.makeModelIndex(cell.index)) }
                    }
                }
            }

            RowLayout {
                anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                spacing: 16
                Kirigami.Icon { source: "user-desktop-symbolic"; isMask: true; color: "white"
                    implicitWidth: 20; implicitHeight: 20
                    TapHandler { onTapped: sys.run("qdbus6 org.kde.kglobalaccel /component/kwin org.kde.kglobalaccel.Component.invokeShortcut \"Show Desktop\"") } }
                StatusArea { iconSize: 20; fontSize: 13 }
            }
        }
    }
}
