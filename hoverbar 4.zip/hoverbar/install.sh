#!/usr/bin/env bash
# usage: ./install.sh [top|bottom]
set -e
EDGE="${1:-top}"
case "$EDGE" in top|bottom) ;; *) echo "edge must be top or bottom"; exit 1;; esac
cd "$(dirname "$0")"

# remove anything left over from the old custom-app versions
pkill -x hoverbar 2>/dev/null || true
rm -f ~/.config/autostart/hoverbar.desktop ~/.local/bin/hoverbar
dbus-send --session --dest=org.kde.KWin --type=method_call /Scripting \
  org.kde.kwin.Scripting.unloadScript string:hoverbar-panelwatch >/dev/null 2>&1 || true

# one-time backup of your current panel layout
B="$HOME/.config/hoverbar-backup"
if [ ! -d "$B" ]; then
  mkdir -p "$B"
  cp ~/.config/plasma-org.kde.plasma.desktop-appletsrc ~/.config/plasmashellrc "$B"/ 2>/dev/null || true
  echo "Backed up current panels to $B"
fi

JS="$(sed "s/__EDGE__/$EDGE/" layout.js)"
dbus-send --session --print-reply --dest=org.kde.plasmashell /PlasmaShell \
  org.kde.PlasmaShell.evaluateScript string:"$JS"
echo
echo "Done. Thin bar is always visible; push the pointer against the $EDGE screen edge to reveal the full KDE panel."
