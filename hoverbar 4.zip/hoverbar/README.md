# HoverBar v3 – 100% native KDE Plasma 6 (no custom app, nothing to build)

Two stock Plasma panels on the same screen edge:

1. **Thin bar** (26px, always visible, translucent): real Kickoff start menu, global menu, system tray
   (monochrome icons), clock + date. Reserves its own strip, so windows never jump.
2. **Full KDE panel** (48px, floating, *auto-hide*): Kickoff, Icon-only Task Manager, show desktop, tray, clock.
   Push the pointer against the screen edge and Plasma slides it in with its native animation;
   move away and it hides again.

Because both are normal Plasma panels there is no extra process, no overlay window, no D-Bus glue and no
state to get stuck: window buttons and the start menu are the real KDE ones.

## Install / change edge
    ./install.sh top        # or: ./install.sh bottom
Backs up your current panels (once) to ~/.config/hoverbar-backup, then replaces them.
Also removes the old HoverBar app/autostart if you had it.

## Undo
    ./restore.sh

## Customise
Edit layout.js (heights, widgets, `floating`, `opacity`) and run ./install.sh again.
Fine-tune manually: right-click a panel > Edit Mode (visibility, floating, opacity, widgets).

## Troubleshooting
- Full panel doesn't appear: Edit Mode > that panel > Visibility must be "Auto Hide"; push the pointer
  against the very edge of the screen.
- Needs: Plasma 6 and `dbus-send` (present on every KDE install). Kickoff/appmenu/icontasks are stock widgets.
