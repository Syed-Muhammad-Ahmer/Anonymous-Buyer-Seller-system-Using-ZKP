#!/usr/bin/env bash
# Puts your original panels back.
B="$HOME/.config/hoverbar-backup"
[ -d "$B" ] || { echo "No backup found in $B"; exit 1; }
cp "$B"/plasma-org.kde.plasma.desktop-appletsrc "$B"/plasmashellrc ~/.config/ 2>/dev/null
systemctl --user restart plasma-plasmashell.service 2>/dev/null || { kquitapp6 plasmashell; sleep 1; setsid plasmashell >/dev/null 2>&1 & }
echo "Original panel layout restored."
