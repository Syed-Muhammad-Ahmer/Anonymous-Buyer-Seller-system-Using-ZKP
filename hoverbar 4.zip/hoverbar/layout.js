// Plasma desktop-scripting layout: thin always-visible bar + real KDE panel that auto-hides on the same edge.
var EDGE = "__EDGE__";
var log = [];
function opt(f) { try { f(); } catch (e) { log.push(String(e)); } }

// start from a clean slate (backup is made by install.sh)
var old = panels();
for (var i = old.length - 1; i >= 0; i--) old[i].remove();

function clock(w) {
    opt(function () {
        w.currentConfigGroup = ["Appearance"];
        w.writeConfig("showDate", true);
        w.writeConfig("dateDisplayFormat", "BesideTime");
    });
}

// ---- 1) thin, always-visible bar (macOS-menu-bar style): start menu, global menu, tray, clock ----
var thin = new Panel();
thin.location = EDGE;
thin.height = 26;
thin.hiding = "none";
opt(function () { thin.floating = false; });
opt(function () { thin.opacity = "translucent"; });
thin.addWidget("org.kde.plasma.kickoff");
opt(function () { thin.addWidget("org.kde.plasma.appmenu"); });
thin.addWidget("org.kde.plasma.panelspacer");
thin.addWidget("org.kde.plasma.systemtray");
clock(thin.addWidget("org.kde.plasma.digitalclock"));

// ---- 2) full standard KDE taskbar: slides in when the pointer pushes against the screen edge ----
var full = new Panel();
full.location = EDGE;
full.height = 48;
full.hiding = "autohide";
opt(function () { full.floating = true; });
full.addWidget("org.kde.plasma.kickoff");
full.addWidget("org.kde.plasma.icontasks");
full.addWidget("org.kde.plasma.showdesktop");
full.addWidget("org.kde.plasma.systemtray");
clock(full.addWidget("org.kde.plasma.digitalclock"));

"HoverBar layout applied on edge '" + EDGE + "'" + (log.length ? " (skipped options: " + log.join("; ") + ")" : "");
