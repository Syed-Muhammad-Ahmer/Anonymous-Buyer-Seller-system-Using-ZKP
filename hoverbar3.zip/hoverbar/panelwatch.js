// KWin script: tells HoverBar whether the Plasma panel is currently revealed on screen.
function isPanel(w) { return w && w.dock && w.resourceClass == "plasmashell"; }
function report(w) {
    try {
        var g = w.frameGeometry;
        var o = w.output ? w.output.geometry : workspace.virtualScreenGeometry;
        var ox = Math.min(g.x + g.width, o.x + o.width) - Math.max(g.x, o.x);
        var oy = Math.min(g.y + g.height, o.y + o.height) - Math.max(g.y, o.y);
        var vis = !w.hidden && w.visible !== false && ox > 2 && oy > 2;
        callDBus("org.hoverbar", "/Bar", "org.hoverbar.Bar", "setPanelVisible", vis);
    } catch (e) {}
}
function watch(w) {
    if (!isPanel(w)) return;
    w.frameGeometryChanged.connect(function () { report(w); });
    if (w.hiddenChanged) w.hiddenChanged.connect(function () { report(w); });
    if (w.minimizedChanged) w.minimizedChanged.connect(function () { report(w); });
    report(w);
}
workspace.windowAdded.connect(watch);
var ws = workspace.windowList();
for (var i = 0; i < ws.length; i++) watch(ws[i]);
