#!/usr/bin/env bash
# Turns the standard KDE panel into an auto-hide panel on the SAME edge as HoverBar.
# usage: ./setup-panel.sh [top|bottom]
EDGE="${1:-top}"
qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "
var ps = panels();
if (ps.length === 0) {
  var n = new Panel();
  n.addWidget('org.kde.plasma.kickoff'); n.addWidget('org.kde.plasma.icontasks');
  n.addWidget('org.kde.plasma.marginsseparator'); n.addWidget('org.kde.plasma.systemtray');
  n.addWidget('org.kde.plasma.digitalclock');
  ps = panels();
}
var p = ps[0];
p.location = '$EDGE';
p.hiding = 'autohide';
p.height = 44;
"
echo "KDE panel -> $EDGE edge, auto-hide."
