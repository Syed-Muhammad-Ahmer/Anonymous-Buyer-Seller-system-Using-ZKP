#include <QGuiApplication>
#include <QQuickView>
#include <QQmlContext>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusReply>
#include <QStandardPaths>
#include <QDir>
#include <QTimer>
#include <LayerShellQt/Shell>
#include <LayerShellQt/Window>
#include "backend.h"

static constexpr int THIN = 26;   // bar thickness == reserved strip

static void loadKWinWatcher() {
    QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dir);
    QString path = dir + "/panelwatch.js";
    QFile::remove(path);
    QFile::copy(":/panelwatch.js", path);
    QFile::setPermissions(path, QFile::ReadOwner | QFile::WriteOwner | QFile::ReadGroup | QFile::ReadOther);
    QDBusInterface kw("org.kde.KWin", "/Scripting", "org.kde.kwin.Scripting");
    if (!kw.isValid()) return;
    kw.call("unloadScript", "hoverbar-panelwatch");
    QDBusReply<int> id = kw.call("loadScript", path, "hoverbar-panelwatch");
    if (!id.isValid()) return;
    QDBusInterface s("org.kde.KWin", QString("/Scripting/Script%1").arg(id.value()), "org.kde.kwin.Script");
    s.call("run");
}

int main(int argc, char **argv) {
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    LayerShellQt::Shell::useLayerShell();
    QGuiApplication app(argc, argv);
    app.setApplicationName("hoverbar");

    QString edge = "top";   // must match the edge the KDE panel lives on (see setup-panel.sh)
    for (int i = 1; i < argc; ++i) {
        QString a = argv[i];
        if (a.startsWith("--edge=")) edge = a.mid(7);
    }
    if (edge != "top" && edge != "bottom") edge = "top";
    const bool bottom = edge == "bottom";

    QQuickView bar;
    bar.setColor(Qt::transparent);
    bar.setFlags(Qt::FramelessWindowHint);
    bar.setResizeMode(QQuickView::SizeRootObjectToView);

    Backend be(&bar, bottom);
    QDBusConnection::sessionBus().registerService("org.hoverbar");
    QDBusConnection::sessionBus().registerObject("/Bar", &be, QDBusConnection::ExportAllSlots);

    bar.rootContext()->setContextProperty("sys", &be);
    bar.rootContext()->setContextProperty("THIN", THIN);
    bar.rootContext()->setContextProperty("EDGE", edge);
    bar.setSource(QUrl("qrc:/Main.qml"));

    auto *lw = LayerShellQt::Window::get(&bar);
    lw->setScope("hoverbar");
    lw->setLayer(LayerShellQt::Window::LayerTop);
    auto side = bottom ? LayerShellQt::Window::AnchorBottom : LayerShellQt::Window::AnchorTop;
    lw->setAnchors(LayerShellQt::Window::Anchors(side | LayerShellQt::Window::AnchorLeft | LayerShellQt::Window::AnchorRight));
    lw->setExclusiveZone(THIN);
    lw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    lw->setDesiredSize(QSize(0, THIN));
    bar.resize(1920, THIN);
    bar.show();

    QTimer::singleShot(800, &app, loadKWinWatcher);
    return app.exec();
}
