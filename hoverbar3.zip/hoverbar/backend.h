#pragma once
#include <QObject>
#include <QProcess>
#include <QFile>
#include <QQuickView>
#include <QRegion>

class Backend : public QObject {
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.hoverbar.Bar")
    Q_PROPERTY(bool panelVisible READ panelVisible NOTIFY panelVisibleChanged)
public:
    Backend(QQuickView *bar, bool bottom) : QObject(bar), m_bar(bar), m_bottom(bottom) {}
    bool panelVisible() const { return m_pv; }

    // While the KDE panel is revealed, our bar steps aside: only a 1px strip at the edge stays "solid".
    Q_INVOKABLE void setYield(bool y) {
        if (!y) { m_bar->setMask(QRegion()); return; }
        int h = m_bar->height();
        m_bar->setMask(QRegion(0, m_bottom ? h - 1 : 0, m_bar->width(), 1));
    }
    Q_INVOKABLE void run(const QString &cmd) {
        QStringList a = QProcess::splitCommand(cmd);
        if (a.isEmpty()) return;
        QString p = a.takeFirst();
        QProcess::startDetached(p, a);
    }
    Q_INVOKABLE int battery() {
        QFile f("/sys/class/power_supply/BAT0/capacity");
        return f.open(QIODevice::ReadOnly) ? f.readAll().trimmed().toInt() : -1;
    }
public slots:   // called over D-Bus by the KWin watcher script (panelwatch.js)
    void setPanelVisible(bool v) { if (v != m_pv) { m_pv = v; emit panelVisibleChanged(); } }
signals:
    void panelVisibleChanged();
private:
    QQuickView *m_bar;
    bool m_bottom, m_pv = false;
};
