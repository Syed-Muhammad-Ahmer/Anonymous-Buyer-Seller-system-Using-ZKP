#!/usr/bin/env bash
# usage: ./install.sh [top|bottom]
set -e
EDGE="${1:-top}"
cd "$(dirname "$0")"
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$HOME/.local"
cmake --build build -j"$(nproc)"
cmake --install build
mkdir -p ~/.config/autostart
cat > ~/.config/autostart/hoverbar.desktop <<D
[Desktop Entry]
Type=Application
Name=HoverBar
Exec=$HOME/.local/bin/hoverbar --edge=$EDGE
X-KDE-autostart-phase=2
D
./setup-panel.sh "$EDGE" || echo "Could not reach plasmashell; run ./setup-panel.sh $EDGE later."
echo "Done. Start now with: ~/.local/bin/hoverbar --edge=$EDGE"
