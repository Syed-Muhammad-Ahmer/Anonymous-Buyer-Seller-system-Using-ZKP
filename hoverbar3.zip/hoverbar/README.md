# HoverBar – thin macOS-style bar that reveals the standard KDE panel (Plasma 6, Wayland)

Idle: a 26px mono bar (active window title, mini window icons, wifi, volume, battery, clock).
Touch it: the bar fades out and the REAL KDE panel (Kickoff, Icon-only Task Manager, tray, clock…)
slides in on the same edge with Plasma's own animation. Move away: the panel hides, the thin bar returns.

## How it fits together
- HoverBar (layer-shell) sits on the chosen edge and reserves only the thin strip.
- `setup-panel.sh` makes the first Plasma panel auto-hide and moves it to that same edge.
- A small KWin script (panelwatch.js, loaded automatically) reports panel visibility to HoverBar over
  D-Bus (org.hoverbar) so the bar knows when to step aside/return. If that report never arrives, the
  bar returns after 1.6s (so it never gets stuck).

## Install
    ./install.sh top        # or: ./install.sh bottom
Dependencies: cmake, Qt6 declarative + dbus, layer-shell-qt, plasma-workspace (libtaskmanager), kirigami, qdbus6.
Arch: sudo pacman -S cmake qt6-declarative layer-shell-qt plasma-workspace kirigami
Fedora: sudo dnf install cmake qt6-qtdeclarative-devel layer-shell-qt-devel plasma-workspace-devel kf6-kirigami-devel

Edge must match: `hoverbar --edge=top|bottom` and `./setup-panel.sh top|bottom` (left/right not supported;
the bar is horizontal). Uninstall: rm ~/.local/bin/hoverbar ~/.config/autostart/hoverbar.desktop, then set the
panel's visibility back to "Always visible" in Edit Mode.
