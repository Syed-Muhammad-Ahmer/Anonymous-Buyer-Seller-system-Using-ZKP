import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager

// Thin mono bar. Touching it reveals the real KDE panel (auto-hide, same edge); we step aside meanwhile.
Item {
    id: root
    property bool yielded: false
    property bool armed: true
    property bool sawPanel: false
    property date now: new Date()
    property int batt: sys.battery()
    property string activeTitle: "Desktop"

    function doYield() { yielded = true; armed = false; sawPanel = false; sys.setYield(true); fallback.restart(); maxT.restart() }
    function restore() { yielded = false; sys.setYield(false); fallback.stop(); maxT.stop() }

    HoverHandler {
        onHoveredChanged: {
            if (hovered && root.armed && !root.yielded) edgeT.restart()
            else if (!hovered) { edgeT.stop(); root.armed = true }
        }
    }
    Timer { id: edgeT; interval: 110; onTriggered: root.doYield() }
    Timer { id: fallback; interval: 1600; onTriggered: root.restore() }   // panel never appeared -> come back
    Timer { id: maxT; interval: 30000; onTriggered: root.restore() }      // safety net
    Connections {
        target: sys
        function onPanelVisibleChanged() {
            if (!root.yielded) return
            if (sys.panelVisible) { root.sawPanel = true; fallback.stop() }
            else if (root.sawPanel) root.restore()                         // panel hid again -> bar returns
        }
    }
    Timer { interval: 1000; running: true; repeat: true
        onTriggered: { root.now = new Date(); root.batt = sys.battery() } }

    TaskManager.VirtualDesktopInfo { id: vdi }
    TaskManager.ActivityInfo { id: ai }
    TaskManager.TasksModel {
        id: tasks
        virtualDesktop: vdi.currentDesktop
        activity: ai.currentActivity
        filterByVirtualDesktop: false
        filterByScreen: false
        groupMode: TaskManager.TasksModel.GroupDisable
        sortMode: TaskManager.TasksModel.SortManual
    }

    component StatusArea: RowLayout {
        property int iconSize: 14
        spacing: 10
        Kirigami.Icon { source: "network-wireless-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("systemsettings kcm_networkmanagement") } }
        Kirigami.Icon { source: "audio-volume-high-symbolic"; isMask: true; color: "white"
            implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.run("pactl set-sink-mute @DEFAULT_SINK@ toggle") }
            WheelHandler { onWheel: function (e) {
                sys.run("pactl set-sink-volume @DEFAULT_SINK@ " + (e.angleDelta.y > 0 ? "+5%" : "-5%")) } } }
        RowLayout { visible: root.batt >= 0; spacing: 3
            Kirigami.Icon { source: "battery-symbolic"; isMask: true; color: "white"
                implicitWidth: iconSize; implicitHeight: iconSize }
            Text { text: root.batt + "%"; color: "white"; font.pixelSize: 11 } }
        Text { text: Qt.formatDateTime(root.now, "ddd d MMM  hh:mm"); color: "white"
            font.pixelSize: 12; font.weight: Font.Medium }
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0.08, 0.08, 0.09, 0.88)
        opacity: root.yielded ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

        RowLayout {
            anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
            spacing: 10
            Kirigami.Icon { source: "start-here-kde-symbolic"; isMask: true; color: "white"
                implicitWidth: 13; implicitHeight: 13
                TapHandler { onTapped: sys.run("qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.activateLauncherMenu") } }
            Text { text: root.activeTitle; color: "white"; font.pixelSize: 12; font.weight: Font.DemiBold
                elide: Text.ElideRight; Layout.maximumWidth: 280 }
            Repeater {
                model: tasks
                delegate: Kirigami.Icon {
                    required property var model
                    readonly property bool act: model.IsActive
                    readonly property string t: model.display
                    onActChanged: if (act) root.activeTitle = t
                    onTChanged: if (act) root.activeTitle = t
                    Component.onCompleted: if (act) root.activeTitle = t
                    source: model.decoration; implicitWidth: 12; implicitHeight: 12
                    isMask: true; color: "white"; opacity: act ? 1.0 : 0.4
                }
            }
        }
        StatusArea { anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } }
    }
}
