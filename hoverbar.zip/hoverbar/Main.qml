import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.taskmanager as TaskManager

Item {
    id: root
    readonly property int full: 58
    readonly property bool expanded: hover.hovered || holdTimer.running
    readonly property real p: Math.max(0, Math.min(1, (bar.height - THIN) / (full - THIN)))
    property date now: new Date()
    property int batt: sys.battery()

    HoverHandler { id: hover; onHoveredChanged: if (!hovered) holdTimer.restart() }
    Timer { id: holdTimer; interval: 450 }          // small grace so it doesn't flicker shut
    Timer { interval: 1000; running: true; repeat: true; onTriggered: { root.now = new Date(); root.batt = sys.battery() } }

    TaskManager.VirtualDesktopInfo { id: vdi }
    TaskManager.ActivityInfo { id: ai }
    TaskManager.TasksModel {
        id: tasks
        virtualDesktop: vdi.currentDesktop
        activity: ai.currentActivity
        filterByVirtualDesktop: false
        filterByScreen: false
        groupMode: TaskManager.TasksModel.GroupDisable
    }

    component StatusArea: RowLayout {
        property int iconSize: 14
        property int fontSize: 11
        spacing: 9
        Kirigami.Icon { source: "network-wireless-symbolic"; isMask: true; color: "white"; implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.launch("systemsettings kcm_networkmanagement") } }
        Kirigami.Icon { source: "audio-volume-high-symbolic"; isMask: true; color: "white"; implicitWidth: iconSize; implicitHeight: iconSize
            TapHandler { onTapped: sys.launch("systemsettings kcm_pulseaudio") } }
        RowLayout { visible: root.batt >= 0; spacing: 3
            Kirigami.Icon { source: "battery-symbolic"; isMask: true; color: "white"; implicitWidth: iconSize; implicitHeight: iconSize }
            Text { text: root.batt + "%"; color: "white"; font.pixelSize: fontSize } }
        Text { text: Qt.formatDateTime(root.now, "ddd d MMM  hh:mm"); color: "white"; font.pixelSize: fontSize + 1; font.weight: Font.Medium }
    }

    Rectangle {
        id: bar
        width: parent.width
        height: root.expanded ? root.full : THIN
        y: 0
        color: Qt.rgba(0.08, 0.08, 0.09, 0.80 + 0.12 * root.p)
        bottomLeftRadius: 16 * root.p
        bottomRightRadius: 16 * root.p
        Behavior on height { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }
        onHeightChanged: sys.setInputHeight(Math.ceil(height))

        // ---- collapsed (thin, mono) ----
        Item {
            anchors.fill: parent
            opacity: 1 - root.p
            visible: opacity > 0.01
            RowLayout {
                anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                spacing: 10
                Kirigami.Icon { source: "applications-all-symbolic"; isMask: true; color: "white"; implicitWidth: 13; implicitHeight: 13 }
                Repeater {
                    model: tasks
                    delegate: Kirigami.Icon {
                        required property var model
                        source: model.decoration; implicitWidth: 13; implicitHeight: 13
                        isMask: true; color: "white"; opacity: model.IsActive ? 1.0 : 0.45
                    }
                }
            }
            StatusArea {
                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
            }
        }

        // ---- expanded (full taskbar) ----
        Item {
            anchors.fill: parent
            opacity: root.p
            visible: opacity > 0.01
            transform: Translate { y: (1 - root.p) * -8 }

            Kirigami.Icon {
                anchors { left: parent.left; leftMargin: 18; verticalCenter: parent.verticalCenter }
                source: "start-here-kde"; implicitWidth: 34; implicitHeight: 34
                TapHandler { onTapped: sys.launch("krunner") }
            }

            RowLayout {
                anchors.centerIn: parent
                spacing: 10
                Repeater {
                    model: tasks
                    delegate: Item {
                        id: cell
                        required property int index
                        required property var model
                        implicitWidth: 44; implicitHeight: 44
                        Kirigami.Icon {
                            anchors.centerIn: parent
                            source: cell.model.decoration
                            width: 34; height: 34
                            scale: th.hovered ? 1.28 : 1.0
                            Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                        }
                        Rectangle { // active dot
                            width: 5; height: 5; radius: 3; color: "white"
                            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: -2 }
                            visible: cell.model.IsActive
                        }
                        HoverHandler { id: th }
                        TapHandler { onTapped: tasks.requestActivate(tasks.makeModelIndex(cell.index)) }
                        TapHandler { acceptedButtons: Qt.MiddleButton; onTapped: tasks.requestNewInstance(tasks.makeModelIndex(cell.index)) }
                        TapHandler { acceptedButtons: Qt.RightButton; onTapped: tasks.requestClose(tasks.makeModelIndex(cell.index)) }
                    }
                }
            }

            StatusArea {
                anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                iconSize: 20; fontSize: 13
            }
        }
    }
}
