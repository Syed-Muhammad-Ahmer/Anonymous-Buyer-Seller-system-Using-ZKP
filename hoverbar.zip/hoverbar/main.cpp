#include <QGuiApplication>
#include <QQuickView>
#include <QQmlContext>
#include <LayerShellQt/Shell>
#include <LayerShellQt/Window>
#include "helper.h"

static constexpr int THIN = 26;      // reserved space (collapsed bar height)
static constexpr int FULL_SURFACE = 80; // surface height so expanded bar fits

int main(int argc, char **argv) {
    qputenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1");
    LayerShellQt::Shell::useLayerShell();
    QGuiApplication app(argc, argv);

    QQuickView view;
    view.setColor(Qt::transparent);
    view.setFlags(Qt::FramelessWindowHint);
    view.setResizeMode(QQuickView::SizeRootObjectToView);

    auto *helper = new Helper(&view);
    view.rootContext()->setContextProperty("sys", helper);
    view.rootContext()->setContextProperty("THIN", THIN);
    view.setSource(QUrl("qrc:/Main.qml"));

    auto *lw = LayerShellQt::Window::get(&view);
    lw->setScope("hoverbar");
    lw->setLayer(LayerShellQt::Window::LayerTop);
    lw->setAnchors(LayerShellQt::Window::Anchors(
        LayerShellQt::Window::AnchorTop | LayerShellQt::Window::AnchorLeft | LayerShellQt::Window::AnchorRight));
    lw->setExclusiveZone(THIN); // windows only reserve the thin strip; expansion overlays them
    lw->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    lw->setDesiredSize(QSize(0, FULL_SURFACE));

    view.resize(1920, FULL_SURFACE);
    view.show();
    return app.exec();
}
