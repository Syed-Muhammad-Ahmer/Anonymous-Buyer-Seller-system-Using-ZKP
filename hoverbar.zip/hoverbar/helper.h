#pragma once
#include <QObject>
#include <QProcess>
#include <QFile>
#include <QQuickView>
#include <QRegion>

class Helper : public QObject {
    Q_OBJECT
public:
    explicit Helper(QQuickView *v) : QObject(v), m_view(v) {}
    // Only the visible bar receives input; the rest of the surface is click-through.
    Q_INVOKABLE void setInputHeight(int h) { m_view->setMask(QRegion(0, 0, m_view->width(), h)); }
    Q_INVOKABLE void launch(const QString &cmd) {
        QStringList a = QProcess::splitCommand(cmd);
        if (a.isEmpty()) return;
        QString p = a.takeFirst();
        QProcess::startDetached(p, a);
    }
    Q_INVOKABLE int battery() {
        QFile f("/sys/class/power_supply/BAT0/capacity");
        if (!f.open(QIODevice::ReadOnly)) return -1;
        return f.readAll().trimmed().toInt();
    }
private:
    QQuickView *m_view;
};
