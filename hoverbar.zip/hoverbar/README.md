# HoverBar – thin macOS-style bar for KDE Plasma 6 (Wayland)

Thin 26px mono bar (small icons, battery, wifi, volume, clock). Hover → smoothly
expands into a full taskbar (big icons, zoom on hover, active dot, launcher).
Expansion overlays windows, so nothing jumps around.

## Dependencies
- Arch:   sudo pacman -S cmake qt6-declarative layer-shell-qt plasma-workspace kirigami
- Fedora: sudo dnf install cmake qt6-qtdeclarative-devel layer-shell-qt-devel plasma-workspace-devel kf6-kirigami-devel
- Debian/Neon: sudo apt install cmake qt6-declarative-dev liblayershellqtinterface-dev libtaskmanager-dev

## Install
    ./install.sh
Then delete the stock panel (Edit Mode → Delete Panel) and run `hoverbar` (it autostarts on login).

## Use
Left click icon = focus window · middle = new instance · right = close window
Tweak: THIN / FULL_SURFACE in main.cpp, `full` + animation duration/easing in Main.qml.
Uninstall: rm ~/.local/bin/hoverbar ~/.config/autostart/hoverbar.desktop; recreate the panel.
